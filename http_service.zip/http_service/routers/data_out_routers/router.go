package dataoutrouters

import (
	"fmt"
	"log/slog"

	"github.com/gin-gonic/gin"
)

func RegisterRoutes(router *gin.RouterGroup) {
	group := router.Group("/data-out")
	group.GET("/:topic", SendToFrontEndRouter)
}

// SendToFrontEndRouter websocket router ----------------------------------
// @Summary Send To Front End by websocket
// @Description # 数据订阅接口
// @Description ## 使用方法
// @Description ```javascript
// @Description var ws = new WebSocket("ws://10.30.24.115:8060/api/v1/data-out/machinning-center");
// @Description
// @Description ws.onmessage = function(event) {
// @Description   console.log(event.data);
// @Description };
// @Description
// @Description ws.onopen = function() {
// @Description   console.log("Connection established");
// @Description };
// @Description
// @Description ws.onclose = function() {
// @Description   console.log("Connection closed");
// @Description };
// @Description ```
// @Description ## topic参数说明
// @Description topic为订阅的数据频道，目前支持的频道有：
// @Description - machinning-center：机床中心数据
// @Description - measrurement-tool：测量工具数据(蓝牙量具)
// @Tags Data Out
// @Accept json
// @Produce json
// @Router /api/v1/data-out/{topic} [get]
// @Success 200 {string} string "Hello, World!"
func SendToFrontEndRouter(c *gin.Context) {
	topic := c.Param("topic")
	slog.Info(fmt.Sprintf("SendToFrontEndRouter: topic=%s", topic))
	SendToFrontEnd(c, func() []byte { return []byte("Hello, World!") })
}

// javascript code to receive data from server:
/*

var ws = new WebSocket("ws://localhost:8060/api/v1/data-out/machinning-center");

ws.onmessage = function(event) {

  console.log(event.data);
};

ws.onopen = function() {

  console.log("Connection established");
};


ws.onclose = function() {

  console.log("Connection closed");
};


*/
