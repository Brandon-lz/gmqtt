package datainrouters

import (
	"data-collector/http_service/core"
	machinningcenter "data-collector/service/machinning_center"
	"data-collector/utils"
	"time"

	"github.com/gin-gonic/gin"
)

// UploadMachinningCenterData router ---------------------------------------
// @Summary Upload Machinning Center Data
// @Description Upload Machinning Center Data
// @Tags Machinning Center Data
// @Produce json
// @Param body body UploadMachinningCenterDataRequest true "datum schema"
// @Success 200 {object} core.ApiOKResponse
// @Router /api/v1/data-in/machinning-center [post]
func UploadMachinningCenterData(c *gin.Context) {
	// TODO: Implement Machinning Center Data In Router
	var req UploadMachinningCenterDataRequest
	utils.PrintDataAsJson(req)
	core.BindParamAndValidate(c, &req)
	machinningcenter.DealData(req.Value, req.Time)
	core.SuccessHandler(c, nil)
}

type UploadMachinningCenterDataRequest struct {
	Time  time.Time `json:"time" form:"time" binding:"required" example:"2021-10-10T10:10:10Z"`
	Value struct {
		OuterCircleSizeByTheory          float64 `json:"outer_circle_size_by_theory"`
		OuterCircleXAxisSizeByExperiment float64 `json:"outer_circle_x_axis_size_by_experiment"`
		OuterCircleYAxisSizeByExperiment float64 `json:"outer_circle_y_axis_size_by_experiment"`
	} `json:"value" form:"value" binding:"required"`
}