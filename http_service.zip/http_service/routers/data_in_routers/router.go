package datainrouters

import "github.com/gin-gonic/gin"

func RegisterRoutes(router *gin.RouterGroup) {
	group := router.Group("/data-in")
	group.POST("/machinning-center", UploadMachinningCenterData)
}
